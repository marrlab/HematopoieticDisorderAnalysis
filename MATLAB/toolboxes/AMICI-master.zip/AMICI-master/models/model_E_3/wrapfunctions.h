#ifndef _amici_wrapfunctions_h
#define _amici_wrapfunctions_h

#include "model_E_3.h"

std::unique_ptr<amici::Model> getModel();

#endif /* _amici_wrapfunctions_h */
